import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt

font = {'size':15}

#20x20map
#data = [[0.92,1.00,0.96],
#        [0.80,0.98,0.88],
#        [0.54,0.92,0.64],
#        [0.16,0.70,0.18]
#]
#x = range(30,70,10)

#5obs-20x20map
data = [[0.98,1.00,0.96],
        [0.90,0.98,0.54],
        [0.52,0.76,0.28]
]
x = range(30,60,10)

arr=np.array(data)

data = np.transpose(arr)
plt.xlabel('Agents',font)
plt.ylabel('Success Rate',font)
plt.tick_params(labelsize=12)
plt.ylim(-0.05,1.05)
fig = plt.gcf()
fig.set_size_inches(5,5)


plt.plot(x, data[0],'o-',markerfacecolor='w',label='CBSH')
plt.plot(x, data[1],'>-',markerfacecolor='w',label='CBSH-R')
plt.plot(x, data[2],'d-',markerfacecolor='w',label='EPEA*')
#plt.plot(x, data[3],'s-',markerfacecolor='w',label='MAXSUM-2')
#plt.plot(x, data[4],'p-',markerfacecolor='w',label='SAT')


# legend = plt.legend(loc='center left',frameon=False,fontsize='large')
legend = plt.legend(loc='top right',frameon=False,fontsize='large')
# Put a nicer background color on the legend.
legend.get_frame().set_facecolor('w')



plt.show()