import csv
import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt

delta_time=1
filenames = ['D:\\test\\plot\\10obs-20x20\\10obs-20x20map-50agents-']
#'D:\\test\\plot\\20x20map-60agents-'
InsNum = len(filenames)*50
font = {'size':15}
plt.xscale('log')
plt.xlabel('Runtime (ms)',font)
plt.ylabel('Success Rate',font)
plt.tick_params(labelsize=12)
plt.ylim(-0.05,1.05)
#plt.xticks([10,100,1000,10000,100000], ('0,01','0,1','1', '10', '100'))
#plt.xlim(1,300000)
fig = plt.gcf()
fig.set_size_inches(5,5)
#CBSH
data=[]
for filename in filenames:
    with open(filename + 'CBSH.csv','r') as csvfile:
        for line in csvfile.readlines():
            array=line.split(",")
            data.append(int(array[0]))

stat=[]
for i in range(0,300000,delta_time):
    count = 0
    for n in data:
        if n <= i:
            count = count + 1
    stat.append(count / InsNum)
plt.plot(range(0,300000,delta_time), stat,label='CBSH')

#Rect
data=[]
for filename in filenames:
    with open(filename + 'CBSH-CR.csv','r') as csvfile:
        for line in csvfile.readlines():
            array=line.split(",")
            data.append(int(array[0]))

stat=[]
for i in range(0,300000,delta_time):
    count = 0
    for n in data:
        if n <= i:
            count = count + 1
    stat.append(count / InsNum)
plt.plot(range(0,300000,delta_time), stat,label='CBSH-CR')

data=[]
for filename in filenames:
    with open(filename + 'CBSH-R.csv','r') as csvfile:
        for line in csvfile.readlines():
            array=line.split(",")
            data.append(int(array[0]))

stat=[]
for i in range(0,300000,delta_time):
    count = 0
    for n in data:
        if n <= i:
            count = count + 1
    stat.append(count / InsNum)
plt.plot(range(0,300000,delta_time), stat,label='CBSH-R')

data=[]
for filename in filenames:
    with open(filename + 'CBSH-RM.csv','r') as csvfile:
        for line in csvfile.readlines():
            array=line.split(",")
            data.append(int(array[0]))

stat=[]
for i in range(0,300000,delta_time):
    count = 0
    for n in data:
        if n <= i:
            count = count + 1
    stat.append(count / InsNum)
plt.plot(range(0,300000,delta_time), stat,label='CBSH-RM')


legend = plt.legend(loc='best',frameon=False,fontsize='large')

plt.show()